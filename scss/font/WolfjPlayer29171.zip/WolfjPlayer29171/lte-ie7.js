/* Load this script using conditional IE comments if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'WolfjPlayer\'">' + entity + '</span>' + html;
	}
	var icons = {
			'wolf-jplayer-ui-amazon' : '&#xe000;',
			'wolf-jplayer-ui-apple' : '&#xe001;',
			'wolf-jplayer-ui-cart' : '&#xe002;',
			'wolf-jplayer-ui-volume-mute' : '&#xe003;',
			'wolf-jplayer-ui-volume-medium' : '&#xe004;',
			'wolf-jplayer-ui-volume-high' : '&#xe005;',
			'wolf-jplayer-ui-volume-mute-2' : '&#xe006;',
			'wolf-jplayer-ui-volume-low' : '&#xe007;',
			'wolf-jplayer-ui-play' : '&#xe008;',
			'wolf-jplayer-ui-pause' : '&#xe009;',
			'wolf-jplayer-ui-stop' : '&#xe00a;',
			'wolf-jplayer-ui-backward' : '&#xe00b;',
			'wolf-jplayer-ui-forward' : '&#xe00c;',
			'wolf-jplayer-ui-first' : '&#xe00d;',
			'wolf-jplayer-ui-last' : '&#xe00e;',
			'wolf-jplayer-ui-share' : '&#xe00f;',
			'wolf-jplayer-ui-shuffle' : '&#xe010;',
			'wolf-jplayer-ui-repeat' : '&#xe011;',
			'wolf-jplayer-ui-spinner' : '&#xe012;',
			'wolf-jplayer-ui-new-window' : '&#xe013;',
			'wolf-jplayer-ui-download-alt' : '&#xf019;',
			'wolf-jplayer-ui-download' : '&#xe014;',
			'wolf-jplayer-ui-cloud-download' : '&#xe015;',
			'wolf-jplayer-ui-cloud-download-2' : '&#xf0ed;',
			'wolf-jplayer-ui-box-add' : '&#xe016;',
			'wolf-jplayer-ui-download-2' : '&#xe017;',
			'wolf-jplayer-ui-download-3' : '&#xe018;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/wolf-jplayer-ui-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
};